package com.klu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.klu.model.EmailManager;

@RestController
@RequestMapping("/email")
public class EmailController 
{
	@Autowired
	EmailManager em;
	@GetMapping("/send")
	public String send()
	{
		String frommail="balajee.rm@gmail.com";
		String toemail="balajee.rm@gmail.com";
		String subject="welcome to emailing";
		String text="Hello hai sir";
		return em.sendEmail(frommail, toemail, subject, text);
	}

}
