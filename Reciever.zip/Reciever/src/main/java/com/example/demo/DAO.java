package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DAO {

	@Autowired
	Repository repo;
	
	public void update (Bank c1) {
		if (repo.existsById(c1.getId()) == true)
		{
			Bank c2 = repo.findById(c1.getId()).get();
			c2.setAmount(c2.getAmount()+c1.getAmount());
			repo.save(c2);
		}
		else {
			repo.save(c1);
		}
	}
	
	public double getBalance(int id) {
		return repo.findById(id).get().getAmount();
	}
	
}
