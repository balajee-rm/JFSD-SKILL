package com.example.demo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SpringController {
	  
	@Autowired
	DAO dao;
	
	  @GetMapping("/test")
	  @ResponseBody
	  public String fun1() {
	    return "ruuning receiver";
	  }
	  
	  @GetMapping("/receiver/{id}/{amount}")
	  @ResponseBody
	  public String receiver(@PathVariable("id") int id, @PathVariable("amount") double amount) {
		  Bank c1 = new Bank();
		  c1.setId(id);
		  c1.setAmount(amount);
		  dao.update(c1);
		  System.out.println("updated successfully");
		  return "Updated Successfully and Account Balance: " + dao.getBalance(id);
	  }
	  
	  @PostMapping("/receiver")
	  @ResponseBody
	  public String receiver2(@RequestBody Bank c1) {
		  dao.update(c1);
		  System.out.println("updated successfully");
		  return "Updated Successfully and Account Balance: " + dao.getBalance(c1.getId());
	  }
	  
	  @GetMapping("/receiver/{id}")
	    @ResponseBody
	    public String receiver3(@PathVariable("id") int id) {
	      String result = null;
	      try {
	        Bank c1 = new Bank();
	        c1.setAmount(dao.getBalance(id));
	        c1.setId(id);
	        URL url = new URL("https://tteow1o1i4.execute-api.ap-south-1.amazonaws.com/prod?amount="+ c1.getAmount());
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        con.setRequestMethod("GET");
	        con.setRequestProperty("Accept", "application/json");
	        con.setUseCaches(false);
	        BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
	        result = br.readLine();
	      } catch (Exception e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	      }
	      return result;
	    }

}
