package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Bank {
	
	@Id
	int id;
	double amount;
   
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public double getAmount() {
	return amount;
}

public void setAmount(double amount) {
	this.amount = amount;
}

@Override
public String toString() {
	return "Bank [id=" + id + ", amount=" + amount + "]";
}

}
