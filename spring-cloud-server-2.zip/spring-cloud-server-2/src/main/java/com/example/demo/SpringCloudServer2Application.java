package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@SpringBootApplication
@EnableConfigServer
public class SpringCloudServer2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudServer2Application.class, args);
		System.out.println("Spring Cloud Config Server Started");
	}

}
