package com.example.demo;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;

@Controller
public class SpringController {
	
	@GetMapping("/test")
	@ResponseBody
	public String fun1 () {
		return "Sender Running";
	}
	
	@GetMapping("/sender/{a}/{b}")
	@ResponseBody
	public String fun4(@PathVariable("a") int a, @PathVariable("b") int b) {
		String result = null;
		URL url;
		try {
			Calculator c1 = new Calculator();
			c1.setA(a);
			c1.setB(b);
			url = new URL("http://localhost:8081/receiever/" + c1.getA() +"/" + c1.getB());
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.setRequestProperty("Accept", "application/json");
			con.setUseCaches(false);
			BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
			result = br.readLine();	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	@GetMapping("/sender2/{a}/{b}")
	@ResponseBody
	public String fun5(@PathVariable("a") int a, @PathVariable("b") int b) {
		String result = null;
		URL url;
		try {
			Calculator c1 = new Calculator();
			c1.setA(a);
			c1.setB(b);
			url = new URL("http://localhost:8081/receiever2");
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Accept", "application/json");
			con.setRequestProperty("Content-Type", "application/json");
			con.setUseCaches(false);
			con.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(new Gson().toJson(c1));
			wr.flush();
			wr.close();
			BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
			result = br.readLine();	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
}
