import logo from './logo.svg';
import './App.css';
import axios from 'axios';

function App() {

  function fun1() {
    alert(document.getElementsByName("id")[0].value)
    axios.post("http://localhost:8080/springmvc/call", {
      id: document.getElementsByName("id")[0].value,
      name: document.getElementsByName("name")[0].value
    }).then((res)=>{
      console.log(res.data)
    })

  }

  function fun2() {
    alert("get request")
    axios.get("http://localhost:8080/springmvc/call", {
      params: {
        id: document.getElementsByName("id")[0].value
    }}).then((res)=>{
      console.log(res.data)
    })
  }

  function fun3() {
    alert("delete request")
    axios.delete("http://localhost:8080/springmvc/call", {
      params: {
        id: document.getElementsByName("id")[0].value
    }}).then((res)=>{
      console.log(res.data)
    })
  }

  function fun4() {
    alert("Update Request")
    axios.put("http://localhost:8080/springmvc/call", {
      id: document.getElementsByName("id")[0].value,
      name: document.getElementsByName("name")[0].value
    }).then((res)=>{
      console.log(res.data)
    })
  }

  function fun5() {
    alert("pagination request")
    axios.get("http://localhost:8080/springmvc/page", {
      params: {
        offset: 3,
        limit: 3
    }}).then((res)=>{
      console.log(res.data)
    })
  }

  

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>Spring MVC</p>
      </header>
      <div className='App-body'>
        <div>
          ID: <input type='number' name='id'/>
          <br></br>
          Name: <input type='text' name='name'/>
          <br/><br/>
          <button onClick={fun1} style={{ boxShadow: "3px 5px 10px red, -3px -5px 10px yellow", borderRadius: "20px" }}> Post Request Submit</button>
          <br/><br/>
          <button onMouseOver={fun2}>Get Request Submit</button>
          <br></br>
          <button onClick={fun3}>Delete Request Submit</button>
          <br></br>
          <button onClick={fun4}>Update Request Submit</button>
          <br></br>
          <button onClick={fun5}>Pagination Request Submit</button>
        </div>
      </div>
    </div>
  );
}

export default App;
