package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class AppController {
	
	public static Map<Integer, Student> student = new HashMap<>();
	static {
		Student s1 = new Student();
		s1.setId(1);
		s1.setName("name 1");
		s1.setCgpa(9.0);
		student.put(s1.getId(), s1);
		
		Student s2 = new Student();
		s2.setId(2);
		s2.setName("name 2");
		s2.setCgpa(9.3);
		student.put(s2.getId(), s2);
	}
	
	@GetMapping("/")
	@ResponseBody
	public String fun1(@RequestParam(value = "name", defaultValue = "abcd") String name) {
		return ("hello world with " + name);
	}
	
	@GetMapping("/second/{name}")
	@ResponseBody
	public String fun2(@PathVariable("name") String name) {
		return ("second page with " + name);
	}
	
	@GetMapping("/welcome")
	public String fun3() {
		return "welcome";
	}
	
	@PostMapping("/save")
	public String insertStudent(@ModelAttribute("stu") Student s, Model m) {
		student.put(s.getId(), s);
		m.addAttribute("stu", student);
		return "show";
	}
	
	@GetMapping("/show")
	public String show(Model m) {
		m.addAttribute("stu", student);
		return "show";
	}
	
	@DeleteMapping("/student/{id}")
	@ResponseBody
	public Map<Integer, Student> deleteStudent(@PathVariable("id") int id) {
		student.remove(id);
		return student;
	}
	
	@PutMapping("/student/{id}")
	@ResponseBody
	public Map<Integer, Student> putStudent(@PathVariable("id") int id, @RequestBody Student s) {
		student.remove(id);
		s.setId(id);
		student.put(id, s);
		return student;
	}
	
	@GetMapping("/jspinsert")
	public String jspInsert(Model m) {
		m.addAttribute("command", new Student());
		return "insert";
	}
	
}
