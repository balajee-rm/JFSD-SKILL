package com.example.demo;

public class Student {
	
	int id;
	String name;
	double cgpa;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCgpa() {
		return cgpa;
	}
	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}
	
	public String toString() {
		return ("ID: " + id + ", NAME: " + name + ", CGPA: " + cgpa);
	}

}
