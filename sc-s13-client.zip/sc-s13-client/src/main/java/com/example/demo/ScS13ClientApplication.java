package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScS13ClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScS13ClientApplication.class, args);
	}

}
