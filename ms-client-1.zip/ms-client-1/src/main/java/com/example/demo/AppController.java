package com.example.demo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClients;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppController {
	
	private final Calculator calculator;

    public AppController(Calculator calculator) {
        this.calculator = calculator;
    }
	
	@GetMapping("/")
	public String fun1() {
		return "Welcome to Client 1";
	}
	
	//http://localhost:8081/client1/10/20
	@GetMapping("/add/{a}/{b}")
	public String fun2(@PathVariable("a") int a, @PathVariable("b") int b) {
		URL url;
		String result = null;
		try {
			url = new URL("http://localhost:8082/add/" + a + "/" + b);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestProperty("Accept", "application/json");
			con.setUseCaches(false);
			BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
			result = br.readLine();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return "Result is: " + result;
	}
	
	@GetMapping("/load/{a}/{b}")
	public String fun3(@PathVariable("a") int a, @PathVariable("b") int b) {
		return calculator.calculate(a, b);
	}
	
	
	
	
	
	
	
	
	
	
}
