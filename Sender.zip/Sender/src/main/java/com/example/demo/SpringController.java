package com.example.demo;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;

@Controller
public class SpringController{
	
	@GetMapping("/test")
	@ResponseBody
	public String fun1() {
		return "Sender Application Running";
	}
	
	@GetMapping("/sender/{id}/{amount}")
    @ResponseBody
    public String sender(@PathVariable("id") int id, @PathVariable("amount") double amount) {
      String result = null;
      try {
        Bank c1 = new Bank();
        c1.setId(id);
        c1.setAmount(amount);
        URL url = new URL("http://15.206.70.93:8082/receiver/"+ c1.getId() + "/" + c1.getAmount());
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("Accept", "application/json");
        con.setUseCaches(false);
        BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
        result = br.readLine();
      } catch (Exception e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
      return result;
    }
    
    @GetMapping("/sender2/{id}/{amount}")
    @ResponseBody
    public String sender2(@PathVariable("id") int id, @PathVariable("amount") double amount) {
      String result = null;
      try {
        Bank c1 = new Bank();
        c1.setId(id);
        c1.setAmount(amount);
        URL url = new URL("http://15.206.70.93:8082/receiver");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("Content-Type","application/json");
        con.setUseCaches(false);
        con.setDoOutput(true);
        DataOutputStream dw = new DataOutputStream(con.getOutputStream());
        dw.writeBytes(new Gson().toJson(c1));
        dw.flush();
        dw.close();
        BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
        result = br.readLine();
      } catch (Exception e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
      return result;
    }
    
    
    @GetMapping("/sender3/{id}")
    @ResponseBody
    public String sender3(@PathVariable("id") int id) {
      String result = null;
      try {
        Bank c1 = new Bank();
        c1.setId(id);
        URL url = new URL("http://15.206.70.93:8082/receiver/"+ c1.getId());
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("Accept", "application/json");
        con.setUseCaches(false);
        BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
        result = br.readLine();
      } catch (Exception e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
      return result;
    }
  
}
