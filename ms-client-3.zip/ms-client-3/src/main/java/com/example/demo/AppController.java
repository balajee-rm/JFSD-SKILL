package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppController {
	
	@GetMapping("/")
	public String fun1() {
		return "Client 3 is Running";
	}
	
	@GetMapping("/add/{a}/{b}")
	public String fun2(@PathVariable("a") int a, @PathVariable("b") int b) {
		Calculator c1 = new Calculator();
		c1.setA(a);
		c1.setB(b);
		return "From Client 3: " + c1.add();
	}
	
}
