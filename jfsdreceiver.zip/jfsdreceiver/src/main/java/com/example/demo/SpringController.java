package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SpringController {
	
	Calculator c1 = new Calculator();
	
	@GetMapping("/test")
	@ResponseBody
	public String fun1 () {
		return "Receiver Running";
	}
	
	@GetMapping("/receiever/{a}/{b}")
	@ResponseBody
	public String fun1(@PathVariable("a") int a, @PathVariable("b") int b) {
		return String.valueOf(c1.add(a, b));	
	}
	
	@PostMapping("/receiever2")
	@ResponseBody
	public String fun2(@RequestBody Calculator c2) {
		return String.valueOf(c1.add(c2.getA(), c2.getB()));	
	}

}
