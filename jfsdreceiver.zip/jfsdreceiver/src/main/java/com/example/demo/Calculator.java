package com.example.demo;

public class Calculator {
	
	int a,b;
	
	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int add(int a, int b) {
		return a+b;
	}
}
