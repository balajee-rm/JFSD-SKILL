package com.klu.spring;

public interface Emp {
	
	public void setId(int id);
	public void setAddress(Address address);
	public int getId();
	public Address getAddress();

}
