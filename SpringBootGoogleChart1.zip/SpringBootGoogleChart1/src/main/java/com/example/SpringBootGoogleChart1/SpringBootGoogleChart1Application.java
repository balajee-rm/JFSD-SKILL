package com.example.SpringBootGoogleChart1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootGoogleChart1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootGoogleChart1Application.class, args);
	}

}
