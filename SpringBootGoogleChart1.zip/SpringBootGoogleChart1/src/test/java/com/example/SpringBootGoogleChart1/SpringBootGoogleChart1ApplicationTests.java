package com.example.SpringBootGoogleChart1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootGoogleChart1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
