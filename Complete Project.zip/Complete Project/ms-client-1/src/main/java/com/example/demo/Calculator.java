package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@LoadBalancerClient(value = "calc", configuration = CalcConfiguration.class)
public class Calculator{

    @Autowired
    RestTemplate restTemplate;

    public String calculate(int a, int b) {
        return restTemplate.getForObject("http://calc/add/" + a + "/" + b, String.class);
    }
    
    public List<Vegetables> veg(String token) {
        return restTemplate.getForObject("http://calc/vegetables?token=" + token, List.class);
    }
}
