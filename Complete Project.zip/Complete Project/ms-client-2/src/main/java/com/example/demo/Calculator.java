package com.example.demo;

public class Calculator {
	
	int a, b, c;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}
	
	public int add() {
		c = a + b;
		return c;
	}
	
	public int sub() {
		c = a - b;
		return c;
	}

}
