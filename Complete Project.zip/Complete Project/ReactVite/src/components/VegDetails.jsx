import { useState } from "react";
import "./VegDetails.css";
const LapDetails = ({store})=>{
    var cart = JSON.parse(localStorage.getItem("cart"))
    const [change, setChange] = useState(0)
    const [laptop,setLaptop] = useState(JSON.parse(localStorage.getItem("element")));
    const [quantity,setQuantity] = useState(1);

    //console.log(cart)

    const handleDecrement = ()=>{
        if(quantity>1){
            setQuantity(prevQuentity => prevQuentity-1);
        }
    }

    const handleIncrement = ()=>{
        if(quantity<laptop.pqty){
            setQuantity(prevQuentity => prevQuentity+1);
        }
    }

    const handleAddToCart = () => {
        cart.push({"item": laptop, "qty": quantity})
        localStorage.setItem('cart', JSON.stringify(cart))
        setChange(1)
        store.dispatch({"type":"page", "data":"VegDetails"})
    };

    
    if(!laptop) return (<div>Loading....</div>)
    
    return(
        <>
            <div className="laptop-details">
                <img src={laptop.pimage}></img>
                <h1>{laptop.pname}</h1>
                <h2><i className="fa fa-rupee"></i> {laptop.pcost}</h2>
                <div className="c1">
                    <button onClick={handleDecrement}> - </button> 
                        <p>{quantity}</p> 
                    <button onClick={handleIncrement}> + </button>
                </div>
                <button className="add_to_cart_btn" onClick={handleAddToCart}>Add To Cart</button>
            </div>
        </>
    )
}
export default LapDetails;