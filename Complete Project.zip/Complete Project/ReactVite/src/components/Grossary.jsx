import { useEffect, useState } from "react";
import axios from "axios";
import "./Vegetables.css";

const Laptops = ({store})=>{
    
    const [laptops,setLaptops] = useState([]);

    const get_laptops = async ()=>{
        const result = await axios.get(`http://localhost:8081/grossary`, {params:{
            "token": localStorage.getItem('token')
            //"token": "eyJhbGciOiJIUzM4NCJ9.eyJwYXNzd29yZCI6ImlvVGRLNGlXTmZYU1BBdWZiVzlPaTEvWk9LblBvR0VWTWFDN1Ruekk5Vzg9Iiwicm9sZSI6IjFwZnByZmJNTVBsOFU1alVOOU15bkE9PSIsIm5hbWUiOiJwOStaaE9GYWFZVU1PcWtDVXg4ZktnPT0iLCJlbWFpbCI6IkFoa2h4WTNXSzZMVEZDaFVFZHhFWlE9PSIsImlhdCI6MTczNDA4MzU1MywiZXhwIjoxNzM0MTY5OTUzfQ.Kbh8mWYr5pwpt01_k1lnGjEHG2F2c2PICLNdieYIGI-yPwAT9LmvXuTxgjvbLaOZ"
        }});
        const {data} = result;
        console.log(data);
        setLaptops(data);
    }
    
    useEffect(()=>{
        get_laptops();
    },[]);

    function fetch_details(element){
        localStorage.setItem("element", JSON.stringify(element))
        store.dispatch({"type":"page", "data":"VegDetails"})
    }

    return(
        <>
            <div className="parent">
                {
                   laptops.map((element,index)=>{
                      return(<div className="child" key={index} onClick={()=> fetch_details(element)}>
                          <img src={element.pimage} width={150} height={150}></img>
                          <h5>{element.pname}</h5>
                          <h6>{element.pcost}</h6>
                      </div>
                    )}) 
                    
                }
            </div>
        </>
    )
}
export default Laptops;