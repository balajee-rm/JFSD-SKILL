import { useEffect, useState } from "react";
import axios from "axios";
import "./Vegetables.css";

const Laptops = ({store})=>{
    
    const [laptops,setLaptops] = useState([]);

    console.log("hello")

    const get_laptops = async ()=>{
        const result = await axios.get(`http://localhost:8081/allorders`, {params:{
            "email": localStorage.getItem('email')
        }});
        const {data} = result;
        console.log(data);
        setLaptops(data);
    }
    
    useEffect(()=>{
        get_laptops();
    },[]);

    function fetch_details(element){
        localStorage.setItem("orders", JSON.stringify(element))
        store.dispatch({"type":"page", "data":"OrderDetails"})
    }

    return(
        <>
            <div className="parent">
                {
                   laptops.map((element,index)=>{
                      return(<div className="child" key={index} onClick={()=> fetch_details(element)}>
                          <h4>Order No: {element.id}</h4>
                          <h5>Name: {element.name}</h5>
                          <h6>Email: {element.email}</h6>
                      </div>
                    )}) 
                    
                }
            </div>
        </>
    )
}
export default Laptops;