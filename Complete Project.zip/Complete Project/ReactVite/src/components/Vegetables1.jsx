import axios from "axios";
import { useState } from "react";

function Vegetables(){

    const [result, setResult] = useState(null)

    axios.get("http://localhost:8081/all")

    if(result == null)
    return(
        <div>
            This is Vegetables Page
        </div>
    );
    else
    return(
        <div>
            result
        </div>
    );
}

export default Vegetables;