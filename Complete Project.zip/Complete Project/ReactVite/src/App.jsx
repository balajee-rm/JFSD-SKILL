import logo from './assets/logo.jpg'
import './App.css'
import SignUp from './components/SignUp.jsx';
import SignIn from './components/SignIn.jsx';
import Appbar from './components/Appbar.jsx'
import Admin from './components/Admin.jsx';
import Vegetables from './components/Vegetables.jsx';
import Grossary from './components/Grossary.jsx';
import Electronics from './components/Electronics.jsx';
import VegDetails from './components/VegDetails.jsx';
import CartPage from './cart/CartPage.jsx';
import Orders from './components/Orders.jsx';
import OrderDetails from './cart/OrderDetails.jsx'

function App({store}) {
  console.log(localStorage.getItem('cart'))
  function Page() {
    switch(store.getState()) {
      case "Signin":
        return (<div> <SignIn store={store} /> </div>)
      case "Signup":
        return (<div> <SignUp /> </div>) 
      case "Vegetables":
        if(localStorage.getItem("role")==1 || localStorage.getItem("role")==2)
        return (<div> <Vegetables store = {store} /> </div>) 
        else
        return (<div> <SignIn store={store} /> </div>)
      case "Grossary":
        if(localStorage.getItem("role")==1 || localStorage.getItem("role")==2)
        return (<div> <Grossary store = {store} /> </div>) 
        else
        return (<div> <SignIn store={store} /> </div>)
      case "Electronics":
        if(localStorage.getItem("role")==1 || localStorage.getItem("role")==2)
        return (<div> <Electronics store = {store} /> </div>) 
        else
        return (<div> <SignIn store={store} /> </div>)
      case "VegDetails":
        if(localStorage.getItem("role")==1 || localStorage.getItem("role")==2)
        return (<div> <VegDetails store = {store} /> </div>) 
        else
        return (<div> <SignIn store={store} /> </div>)
      case "Admin":
        if(localStorage.getItem("role")==1)
        return (<div> <Admin /> </div>) 
        else
        return (<div> <SignIn store={store} /> </div>)
      case "CartPage":
        if(localStorage.getItem("role")==1 || localStorage.getItem("role")==2)
        return (<div> <CartPage store={store} /> </div>) 
        else
        return (<div> <SignIn store={store} /> </div>)
      case "Orders":
        if(localStorage.getItem("role")==1 || localStorage.getItem("role")==2)
        return (<div> <Orders store={store} /> </div>) 
        else
        return (<div> <SignIn store={store} /> </div>)
      case "OrderDetails":
        if(localStorage.getItem("role")==1 || localStorage.getItem("role")==2)
        return (<div> <OrderDetails store={store} /> </div>) 
        else
        return (<div> <SignIn store={store} /> </div>)
    }
  }
  return (
    <div className="App">
      <header className="App-header">
        <div className='heading'>
          <img src={logo} className="App-logo" alt="logo" />
          <p> Grossary Bag </p>
        </div>
        <div className='cart' onClick={()=>store.dispatch({"type":"page", "data":"CartPage"})}> <i class="fa fa-shopping-cart"></i> {JSON.parse(localStorage.getItem('cart')).reduce((sum, item) => sum + item.qty, 0)} </div>
      </header>
      <div className='App-body'>
        <Appbar store = {store} />
        <div className="page"> <Page /> </div> 
      </div>
    </div>
  );
}

export default App;
