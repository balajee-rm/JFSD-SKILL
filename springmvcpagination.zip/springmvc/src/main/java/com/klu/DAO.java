package com.klu;
//DAO class will have queries


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class DAO {
	
	/*
	 * JdbcTemplate jdbcTemplate;
	 * 
	 * public JdbcTemplate getJdbcTemplate() { return jdbcTemplate; }
	 * 
	 * public void setJdbcTemplate(JdbcTemplate jdbcTemplate) { this.jdbcTemplate =
	 * jdbcTemplate; }
	 */
	HibernateTemplate ht;
	
	public HibernateTemplate getHt() {
		return ht;
	}
	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}
	public void insert(Student s) {
		/*
		 * String qry="insert into stus13 values("+s.getId()+",'"+s.getName()+"')"; int
		 * r=jdbcTemplate.update(qry);
		 */
		ht.save(s);
		System.out.println(s);
		
	}
	public void update(Student s) {
		/*
		 * String qry="update stus13 SET name='"+s.getName()+"' where id="+s.getId();
		 * int r=jdbcTemplate.update(qry);
		 */
		ht.update(s);
		System.out.println("updated");
		
	}
	public void delete(int id) {
		/*
		 * String qry="delete from stus13 where id ="+ sid; int
		 * r=jdbcTemplate.update(qry);
		 */
		ht.delete(ht.get(Student.class, id));
		System.out.println("deleted");
		
	}
	public List<Student> retrive() {
		/*
		 * String qry="select * from stus13"; List<Student> l=jdbcTemplate.query(qry,new
		 * RowMapper<Student>(){
		 * 
		 * @Override public Student mapRow(ResultSet rs, int rowNum) throws SQLException
		 * { Student s =new Student(); s.setId(rs.getInt(1));
		 * s.setName(rs.getString(2)); return s; } }); return l;
		 */
		return ht.loadAll(Student.class);	
	}
	public List<Student> pagination(int offset, int limit) {
		SessionFactory sf = ht.getSessionFactory();
		Session s = sf.openSession();
		Query qry = s.createQuery("from Student");
		qry.setFirstResult(offset);
		qry.setMaxResults(limit);
		return qry.list();
		
	}
}