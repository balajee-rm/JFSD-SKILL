package com.klu;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;


@RestController
@CrossOrigin
public class AppController {
  @Autowired
  DAO dao;
  
  @GetMapping ("/welcome")
   public String fun1() {
     return "welcome to controller ";
   }
  //http://localhost:8080/springmvc5/welcome/Balajee
  @GetMapping ("/welcome/{name}")
   public String fun2(@PathVariable("name") String name) {
     return "welcome " + name;
   }
  
  //http://localhost:8080/springmvc5/add?x=10&y=20
  @GetMapping ("/add")
   public String fun3(@RequestParam("x") int a, @RequestParam("y") int b) {
     return "Add value is: " + (a+b);
   }
  
  //http://localhost:8080/springmvc5/call
  @PostMapping ("/call")
   public String fun4(@RequestBody String s) {
     Student s1 = new Gson().fromJson(s, Student.class);
     dao.insert(s1);
     return "Welcome by Post Request and Student is " + s1.toString();
   }
  
  //http://localhost:8080/springmvc5/call
  @GetMapping ("/call")
   public String fun5(@RequestParam("id") int id) {
    List<Student> l=dao.retrive();
     return "Welcome by Get Request and List is " + l;
   }
  
  //http://localhost:8080/springmvc5/call
  @PutMapping ("/call")
   public String fun6(@RequestBody String s) {
     Student s1 = new Gson().fromJson(s, Student.class);
     dao.update(s1);
     return "Welcome by Put Request and Student is " + s1.toString();
   }
  
  //http://localhost:8080/springmvc5/call
  @DeleteMapping ("/call")
   public String fun7(@RequestParam("id") int id) {
    dao.delete(id);
     return "Welcome by Delete Request and ID is " + id;
   }
  
   //http://localhost:8080/springmvc/page?offset=3&limit=3
  	@GetMapping("/page")
  	public String fun8(@RequestParam("offset") int offset, @RequestParam("limit") int limit) {
  		List<Student> l = dao.pagination(offset, limit);
  		return "" + l;
  	}
  
}