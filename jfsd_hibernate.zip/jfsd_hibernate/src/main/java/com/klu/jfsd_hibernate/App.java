package com.klu.jfsd_hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.criterion.Restrictions;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
    	Metadata md = new MetadataSources(ssr).getMetadataBuilder().build();

    	SessionFactory sf = md.getSessionFactoryBuilder().build();
    	Session s = sf.openSession();
    	Transaction t;
    	
    	//Insert
    	Employee e1 = new Employee();
    	e1.setFn("Balajee");
    	e1.setLn("R M");
    	s.save(e1);
    	t = s.beginTransaction();
    	t.commit();
    	System.out.println("Employee Data Inserted");
    	
    	PermanentEmployee e2 = new PermanentEmployee();
    	e2.setFn("JFSD Class");
    	e2.setLn("Hibernate");
    	e2.setSalary(50000);
    	e2.setDept("CSE");
    	s.save(e2);
    	t = s.beginTransaction();
    	t.commit();
    	System.out.println("Permanent Employee Data Inserted");
    	
    	ContractEmployee e3 = new ContractEmployee();
    	e3.setFn("Contract Employee");
    	e3.setLn("Class 3");
    	e3.setDaily_salary(1000);
    	e3.setContract_year(1);
    	s.save(e3);
    	t = s.beginTransaction();
    	t.commit();
    	System.out.println("Contract Employee Data Inserted");
    	
    	/*
    	//Retrieve
    	Employee e2 = s.find(Employee.class, 1);
    	System.out.println("Data Retrieved");
    	
    	//update
    	e2.setFn("JFSD");
    	e2.setLn("Class");
    	s.update(e2);
    	t = s.beginTransaction();
    	t.commit();
    	System.out.println("Data Updated");
    	
    	//delete
    	s.delete(e2);
    	t = s.beginTransaction();
    	t.commit();
    	System.out.println("Data Deleted");
    	*/
    	
    	/*
    	//HCQL
    	Criteria c = s.createCriteria(Employee.class);
    	c.add(Restrictions.gt("id", 2));
    	List<Employee> l = c.list();
    	System.out.println(l.get(0).getId());
    	System.out.println(l.get(0).getFn());
    	*/
    	
    	
        System.out.println( "Hello World!" );
    }
}
