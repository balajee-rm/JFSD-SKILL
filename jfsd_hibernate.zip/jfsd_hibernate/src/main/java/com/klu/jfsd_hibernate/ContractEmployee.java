package com.klu.jfsd_hibernate;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "cont_emp")
public class ContractEmployee extends Employee {
	@Column(name = "dy_sal")
	double daily_salary;
	@Column(name = "cont_yr")
	int contract_year;
	public double getDaily_salary() {
		return daily_salary;
	}
	public void setDaily_salary(double daily_salary) {
		this.daily_salary = daily_salary;
	}
	public int getContract_year() {
		return contract_year;
	}
	public void setContract_year(int contract_year) {
		this.contract_year = contract_year;
	}
}
